const prompt = require('prompt-sync')();
const EventEmitter = require('events');
const eventEmitter = new EventEmitter();
function performOperation(operator, num1, num2)
{
let result;
switch (operator)
{
case '+':
result = num1 + num2;
break;
case'-':
result = num1 - num2;
break;
case'*':
result = num1 * num2;
break; 
case '/':
result = num1/num2;
break;
default:
console.log("Invalid operator.");
return;
}
eventEmitter.emit('calculationResult', result);
}
eventEmitter.on('calculationResult', (result)=>{
console.log('Result: '+result);
    askForinput();
});
function askForinput()
{
const input = prompt("Enter expression :"); 
if(input =='exit')
{
process.exit(0);
}
else
{
const [num1, operator, num2] = input.split("");
if (num1 && operator && num2)
{
performOperation(operator, parseFloat(num1), parseFloat(num2));
}
else
{
console.log("Invalid input. Please enter two numbers and an operator.");
    askForinput();
}
}
}
console.log('Simple Calculator');

console.log('Usage: Enter two numbers and an operator (+, -,*,/) please dont put spaces or type (exit) to terminate');
askForinput();

