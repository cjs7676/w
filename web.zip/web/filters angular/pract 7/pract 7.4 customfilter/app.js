var app = angular.module('filterApp', []);


app.controller('FilterController', function($scope) 
{
   
    $scope.firstname = ''; 
    $scope.lastname = ''; 
    $scope.fullname = ''; 
    $scope.yourtext='';
    

    $scope.convertText = function(type) 
    {
        if (type === 'uppercase') 
	{
            
      		$scope.fullname = $scope.firstname.toUpperCase() + ' ' + $scope.lastname.toUpperCase();
        } 
	else if (type === 'lowercase') 
	{
            $scope.fullname = $scope.firstname.toLowerCase() + ' ' + $scope.lastname.toLowerCase();
        } 
	else
	{
		$scope.yourtext = $scope.firstname + ' ' + $scope.lastname;
	}
    };
});
