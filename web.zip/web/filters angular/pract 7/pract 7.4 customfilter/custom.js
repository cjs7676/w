// Define a new AngularJS module
var app = angular.module('filterApp', []);

app.filter('customFilter', function() {
    return function(input) {
        return input.toUpperCase();
    };
});

// Create a controller for the module
app.controller('FilterController', function($scope) {
    $scope.inputText = '';

});
