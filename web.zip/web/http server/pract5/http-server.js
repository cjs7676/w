const http = require('http');
const url = require('url');
const prompt = require('prompt-sync')();

// Greatest Common Divisor (GCD) of two numbers
function calculateGCD(num1, num2) {
    while (num2 !== 0) {
        const temp = num2;
        num2 = num1 % num2;
        num1 = temp;
    }
    return num1;
}

// Function to reverse a number
function reverseNumber(num) {
    let reversed = 0;
    while (num !== 0) {
        reversed = reversed * 10 + num % 10;
        num = Math.floor(num / 10);
    }
    return reversed;
}
//let n=parseInt(prompt('Enter the first number:'));
//let m=parseInt(prompt('Enter the second number:'));

const server = http.createServer((req, res) => {
    const queryObject = url.parse(req.url, true).query;
    const num1 = parseInt(queryObject.num1);
    const num2 = parseInt(queryObject.num2);

    // call both the functions
    const gcd = calculateGCD(num1, num2);
    const reversedNum1 = reverseNumber(num1);
    const reversedNum2 = reverseNumber(num2);

    // Prepare HTML response
    const htmlResponse = `
        <h1><center>Welcome to the Result Page</h1>
	<h2>The Result is:</h2>
        <p>GCD of ${num1} and ${num2} is: ${gcd}</p>
        <p>Reverse of ${num1} is: ${reversedNum1}</p>
        <p>Reverse of ${num2} is: ${reversedNum2}</p>
    `;

    // Set response headers and send HTML response
    res.writeHead(200, { 'Content-Type': 'text/html' });
    res.end(htmlResponse);
});


const port = 3001;
server.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});