const fs=require('fs');
const prompt = require('prompt-sync')();

function createFile(fileName)
{
	fs.writeFile(fileName,'',(error) =>{
	if(error)
	{
	console.error('error creating the file :',error);
	}
	else
	{
	console.log('file created successfully.');
	}
	});
}

function writeToFile(fileName, content)
{
	fs.appendFile(fileName, content,(error) => {
	if (error)
	{	
		console.error('error writing to the file:',error);
	}
	else
	{
		console.log('content has been written to the file success.');
	}
	});
}

function readFromFile(fileName)
{
	fs.readFile(fileName, 'utf8',(error,data) =>{
	if(error)
	{
		console.error('error reading the file:',error);
	}
	else
	{
		console.log('content read from the file:');
		console.log(data);
	}
	});
}

function deleteFile(fileName)
{
	fs.unlink(fileName, (error) => {
	if(error)
		{
		console.error('error deleteing the file:',error);
	}
	else
	{
		console.log('file has been deleted successfully:');
		
	}
	});
}

function main()
{
	let fileName;
	console.log('menu');
	console.log('1. Create File');
	console.log('2. Write the file');
	console.log('3. Read from file');
	console.log('4. Delete file');
	console.log('5. Exit');
	const choice = parseInt(prompt('enter your choice: '))

	switch(choice)
	{
		case 1: fileName =prompt('enter the file name to be created:');
			createFile(fileName);
			setTimeout(() => {main();}, 1000);
                break;
            case 2:
		fileName = prompt('Enter file name in which data is to be entered: ');
                const content = prompt('Enter content to write to the file: ');
                writeToFile(fileName, content);
		setTimeout(() => {main();}, 1000);
                break;
            case 3:
		fileName = prompt('Enter file name to be read: ');
                readFromFile(fileName);
		setTimeout(() => {main();}, 1000);
                break;		
            case 4:
		fileName = prompt('Enter file name to be deleted: ');
                deleteFile(fileName);
		setTimeout(() => {main();}, 1000);
                break;
            case 5:
                console.log('Exiting program.');
                process.exit(0);
            default:
                console.log('Invalid choice. Please try again.');
        }
}
main();
		
