const fs = require('fs');
const prompt = require('prompt-sync')();

function createFile(fileName) 
{
    fs.writeFile(fileName, '', (error) => {
        if (error) 
	{
            console.error('error creating the file:', error);
        } 
	else 
	{
            console.log('File created successfully.');
        }
    });
}

function writeToFile(fileName, content) 
{
    fs.appendFile(fileName, content, (error) => {
        if (error) 
	{
            console.error('error writing to the file:', error);
        } 
	else 
	{
            console.log('Content has been written to the file successfully.');
        }
    });
}

function readFromFile(fileName) 
{
    fs.readFile(fileName, 'utf8', (error, data) => {
        if (error) 
	{
            console.error('error reading the file:', error);
        } 
	else 
	{
            console.log('Content read from the file:');
            console.log(data);
        }
    });
}

function deleteFile(fileName) {
    fs.unlink(fileName, (error) => {
        if (error) 
	{
            console.error('error deleting the file:', error);
        } 
	else 
	{
            console.log('File has been deleted successfully.');
        }
    });
}

function main() 
{

	let fileName;
        console.log('Menu:');
        console.log('1. Create File');
        console.log('2. Write to File');
        console.log('3. Read from File');
        console.log('4. Delete File');
        console.log('5. Exit');
        const choice = parseInt(prompt('Enter your choice: '))
	
        switch (choice) 
	{
            case 1:
		fileName = prompt('Enter file name to be created: ');
                createFile(fileName);
		setTimeout(() => {main();}, 1000);
                break;
            case 2:
		fileName = prompt('Enter file name in which data is to be entered: ');
                const content = prompt('Enter content to write to the file: ');
                writeToFile(fileName, content);
		setTimeout(() => {main();}, 1000);
                break;
            case 3:
		fileName = prompt('Enter file name to be read: ');
                readFromFile(fileName);
		setTimeout(() => {main();}, 1000);
                break;		
            case 4:
		fileName = prompt('Enter file name to be deleted: ');
                deleteFile(fileName);
		setTimeout(() => {main();}, 1000);
                break;
            case 5:
                console.log('Exiting program.');
                process.exit(0);
            default:
                console.log('Invalid choice. Please try again.');
        }
    
}

main();