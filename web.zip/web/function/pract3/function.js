const prompt = require('prompt-sync')();
// Function to check if a number is prime
function isPrime(num)
{
for(let i=2;i<num;i++)
{
    if (num % i === 0)
    {
        return false;
    }
}
return true;
}
// Function to calculate factorial
function factorial(num) {
if (num === 0 || num === 1)
{
return 1;
}

let result = 1;
for (let i = 2; i <= num; i++) {
result *= i;
}
return result;
}
function fibonacci(n) {
let fibSeries = [0, 1];
for (let i = 2; i < n; i++) {
fibSeries.push(fibSeries[i - 1] + fibSeries[i - 2]);
}
return fibSeries;
}

// Get user input
const num = parseInt(prompt('Enter a number: '));
// Check if the number is prime or calculate its factorial
if (isPrime(num))
{
    console.log(num+" is a prime number.");
}
else{
    console.log(num+ " is not a prime number.");
}
const fact = factorial(num);
console.log("Factorial of " +num+" is: "+fact);
const fibSeries = fibonacci(num);
console.log("Fibonacci series up to "+num+" terms: "+fibSeries.join(','));