// update-test.js
function select_student()
{

			const prompt = require('prompt-sync')();

			const st_id = prompt('Enter the id of student to be displayed: ');
			const db = require('./db');

			db.query('select * from student where s_id = ?',[st_id],  (err, results) => {
  			if (err) 
  			{
    				console.error('Error selecting data: ' + err);
  			} 
			else 
			{
  			  	console.log('Data select:', results);
 			 }

			});
}

module.exports = {
  select_student,
};
