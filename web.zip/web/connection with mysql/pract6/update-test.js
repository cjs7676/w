// update-test.js
function update_student()
{

			const prompt = require('prompt-sync')();
			st_name=prompt('Enter the student name: ');
			st_mobile=prompt('Enter the mobile number: ');
			st_email=prompt('Enter the email address: ');
			const updatedData = {
  						s_name: st_name,
  						s_mobile: st_mobile,
						s_emailid: st_email,
					    };
			const st_id = prompt('Enter the student id of student whose name and mobile has to be updated: ');
			const db = require('./db');

			db.query('UPDATE student SET ? WHERE s_id = ?', [updatedData, st_id], (err, results) => {
  			if (err) 
  			{
    				console.error('Error updating data: ' + err);
  			} 
			else 
			{
  			  	console.log('Data updated:', results.affectedRows);
 			 }

			});
}

module.exports = {
  update_student,
};
