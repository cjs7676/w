// insert-test.js
function insert_student()
{
const prompt = require('prompt-sync')();
st_id=prompt('Enter the student id: ');
st_name=prompt('Enter the student name: ');
st_mobile=prompt('Enter the mobile number: ');
st_emailid=prompt('Enter the email id: ');
const newData = {
  s_id: st_id,
  s_name: st_name,
  s_mobile: st_mobile,
  s_emailid: st_emailid
};
const db = require('./db');
db.query('INSERT INTO student SET ?', newData, (err, results) => {
  if (err) {
    console.error('Error inserting data: ' + err);
  } else {
    console.log('Data inserted. ID:', results.insertId);

  }
});
}
module.exports = {
  insert_student,
};