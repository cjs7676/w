//update.js

const db=require('./db');

const updateData={
	s_id:'2',
	s_name:'ram ',
	s_mobile:'9822137689',
	s_emailid:'ram@gmail.com',
};

const studentid=2;

db.query('update student set ? where s_id=?',[updateData,studentid],(err,results)=>{
	if(err){
		console.error(`Error Updateing data: `+err);
		process.exit(0);
	}else{
		console.log(`Data update : `+results.affectedRows);
		process.exit(0);	
	}
});