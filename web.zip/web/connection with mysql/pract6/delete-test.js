
function delete_student()
{

			const prompt = require('prompt-sync')();

			const st_id = prompt('Enter the id of student to be deleted: ');
			const db = require('./db');

			db.query('delete from student WHERE s_id = ?', [st_id], (err, results) => {
  			if (err) 
  			{
    				console.error('Error Deleting data: ' + err);
  			} 
			else 
			{
  			  	console.log('Data deleted:', results.affectedRows);
 			 }

			});
}

module.exports = {
  delete_student,
};
