
const prompt = require('prompt-sync')();
function displayMenu() 
{
  console.log('Menu');
  console.log('1. Update data in student table');
  console.log('2. Insert data in student table');
  console.log('3. Select data in student table');
  console.log('4. Delete data in student table');
  console.log('5. Exit');
}

function student_data()
{

	var choice;
	displayMenu();

// Get the user's choice
	choice = prompt('Enter your choice: ');

	switch (choice) 
	{
  		case '1':
			const ud = require('./update-test');
			ud.update_student();
			setTimeout(() => {student_data();}, 1000);
			break;
  		case '2':
			const ins = require('./insert-test');
			ins.insert_student();
			setTimeout(() => {student_data();}, 1000);
    			break;
		case '3':
			const sd = require('./select-test');
			sd.select_student();
			setTimeout(() => {student_data();}, 1000);
    			break;
		case '4':
			const dd = require('./delete-test');
			dd.delete_student();
			setTimeout(() => {student_data();}, 1000);
    			break;
  		case '5':
   			console.log('Goodbye!');
			process.exit(0);
    			break;
			
  		default:
    			console.log('Invalid choice');
			break;
	}

}
student_data();

