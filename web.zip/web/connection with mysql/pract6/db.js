// db.js
const mysql=require('mysql');
const connection = mysql.createConnection({
	host:'localhost',
	user:'root',
	password:'root',
	database:'pract6',
});

connection.connect((err)=>{
	if(err){
	console.error(`Error Connecting to My Sql:`+err.stack);
	process.exit(0);
	}
	console.log(`Connected to My Sql as id :`+connection.threadId);
});
module.exports=connection;