//delete.js

const db=require('./db');

const s_id=2;

db.query('delete from student where s_id=?',s_id,(err,results)=>{
	if(err){
		console.error(`Error deleting data: `+err);
		process.exit(0);
	}else{
		console.log(`Data Deleted : `,results.affectedRows);
		process.exit(0);	
	}
});