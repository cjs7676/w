//select.js

const db=require('./db');

db.query('SELECT * from student',(err,results)=>{
	if(err){
		console.error('Error Selecting data:' + err);
		process.exit(0);
	}else{
		console.log('Selected data :' , results);
		process.exit(0);	
	}
});