// insert.js
const db= require('./db');

const newData = {
	s_id:2,
	s_name:'chirag s',
	s_mobile:'123456789',
	s_emailid:'chirag@gmail.com',
};

db.query('INSERT INTO  student SET ?',newData,(err,results)=>{
	if(err){
		console.error('Error inserting data:'+err);
		process.exit(0);
	}
	else{
		console.log('Data inserted Id : '+results.insertId);
		process.exit(0);	
	}
	
});
